@extends('guest.layouts.app')

@section('content')

@endsection

@push('stylesheets')

@endpush

@push('scripts')

@endpush


{{--//        echo '<pre>';--}}
{{--//        var_dump($post_detail);--}}
{{--//        echo '</pre>';--}}
{{--//        die();--}}


